﻿CREATE PROCEDURE [dbo].[CreatePosting]
	@Title NVARCHAR(50),
	@Author NVARCHAR(50),  
    @DescFileName NVARCHAR(MAX), 
    @MinToRead NVARCHAR(50)
AS
	BEGIN
		INSERT INTO Posting (Title, Author, DescFileName, MinToRead)
		VALUES (@Title, @Author, @DescFileName, @MinToRead) 
	END