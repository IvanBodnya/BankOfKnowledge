﻿CREATE PROCEDURE [dbo].[DeletePostingById]
	@Id INT
AS
	BEGIN
		DELETE 
		FROM Posting
		WHERE Id = @Id
	END
