﻿CREATE PROCEDURE [dbo].[GetPostings]
AS
	BEGIN
	SELECT *
	FROM Posting
END
