﻿CREATE PROCEDURE [dbo].[UpdatePosting]
	@Id INT,
	@Title NVARCHAR(50),
	@Author NVARCHAR(50),  
    @DescFileName NVARCHAR(MAX), 
    @MinToRead NVARCHAR(50)
AS
	BEGIN
		UPDATE Posting
		SET Title = @Title, 
			Author = @Author, 
			DescFileName = @DescFileName, 
			MinToRead = @MinToRead,
			DateCreated = getdate()
		WHERE Id = @Id
	END
