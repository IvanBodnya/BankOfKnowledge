﻿CREATE PROCEDURE [dbo].[GetPostingById]
	@PostingId INT
AS
	BEGIN
		SELECT *
		FROM Posting
		WHERE Posting.Id = @PostingId
	END
