﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BOKWeb.Models;
using BOKWeb.Models.DB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;

namespace BOKWeb.Controllers
{
    public class PostingController : Controller
    {
        private IPostingRepository _postingRepository;
        private IHostingEnvironment _hostingEnvironment;

        public PostingController(IPostingRepository postingRepository,
                                 IHostingEnvironment hostingEnvironment)
        {
            _postingRepository = postingRepository;
            //_hostingEnvironment = hostingEnvironment;
        }

        public async Task<IActionResult> Index()
        {
            //string path = _hostingEnvironment.WebRootPath;

            return View(await _postingRepository.GetPostingModels());
        }

        public IActionResult CreatePost()
        {
            return View(_postingRepository.CreateEmptyPostingInstance());
        }

        [HttpPost]
        [ActionName("CreatePost")]
        public async Task<IActionResult> CreatePosting([Bind("Title,Author,MinToRead, Description")] PostingDBModel postingModel)
        {
            await _postingRepository.CreatePostingModel(postingModel);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> DisplayPost(int id)
        {
            return View(await _postingRepository.GetPostingById(id));
        }

        public async Task<IActionResult> EditPost(int id)
        {
            return View(await _postingRepository.GetPostingById(id));
        }

        [HttpPost]
        public async Task<IActionResult> EditPost([Bind("Id, Title, Author, MinToRead, Description")] PostingDBModel postingModel)
        {
            await _postingRepository.UpdatePosting(postingModel);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> DeletePost(int id)
        {
            await _postingRepository.DeletePostingById(id);
            return RedirectToAction("Index");
        }

        [Authorize]
        public IActionResult Secure()
        {
            ViewData["isAuthenticated"] = User.Identity.IsAuthenticated;
            ViewData["email"] = User.FindFirst(c => c.Type.Equals("boeing:email"))?.Value;
            ViewData["bems"] = User.FindFirst(c => c.Type.Equals("boeing:bems"))?.Value;
            ViewData["name"] = User.FindFirst(c => c.Type.Equals("boeing:name"))?.Value;
            return View();
        }
    }
}