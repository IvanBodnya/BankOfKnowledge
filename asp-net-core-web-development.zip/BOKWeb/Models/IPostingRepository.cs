﻿using BOKWeb.Models;
using BOKWeb.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOKWeb.Models
{
    //Used to dictate CRUD operations on PostingModel
    public interface IPostingRepository
    {
        /// <summary>
        /// Creates empty posting (Not Added to DB)
        /// </summary>
        /// <returns></returns>
        PostingDBModel CreateEmptyPostingInstance();

        /// <summary>
        /// Adds PostingModel to the Database asynchronously.
        /// </summary>
        /// <param name="postingModel"></param>
        /// <returns></returns>
        Task CreatePostingModel(PostingDBModel postingModel);

        /// <summary>
        /// Returns a set of postings found in DB
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<PostingDBModel>> GetPostingModels();

        /// <summary>
        /// Returns posting by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PostingDBModel> GetPostingById(int id);

        /// <summary>
        /// Updates posting in DB based on Posting provided through form
        /// </summary>
        /// <param name="postingModel"></param>
        /// <returns></returns>
        Task UpdatePosting(PostingDBModel postingModel);

        /// <summary>
        /// Deletes postiong from DB by referencing its Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task DeletePostingById(int id);
    }
}
