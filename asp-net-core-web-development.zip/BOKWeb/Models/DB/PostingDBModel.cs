﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace BOKWeb.Models.DB
{
    [Table("Posting")]
    public class PostingDBModel
    {
        //public PostingDBModel()
        //{
        //    //Generates the current time once the instance is created
        //    this.DateCreated = DateTime.Now;
        //}

        public int Id { get; set; }

        [Display(Name = "Title")]
        public string Title { get; set; }

        [Display(Name = "Author")]
        public string Author { get; set; }

        [Display(Name = "Creation date")]
        public DateTime DateCreated { get; set; }

        [Display(Name = "Post description")]
        [Column("DescFileName")]
        public string Description { get; set; }

        [Display(Name = "Approx. min to read")]
        public string MinToRead { get; set; }
    }
}
