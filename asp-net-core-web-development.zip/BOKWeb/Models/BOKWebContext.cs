﻿using BOKWeb.Models.DB;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Westwind.AspNetCore.Markdown;

namespace BOKWeb.Models
{
    public class BOKWebContext : DbContext
    {
        private readonly IHostingEnvironment _env;

        public BOKWebContext(DbContextOptions<BOKWebContext> options, 
                            IHostingEnvironment env) : base(options)
        {
            _env = env;
        }

        public DbSet<PostingDBModel> PostingDBModels { get; set; }

        #region Public PostingDBModels methods
        public async Task<IEnumerable<PostingDBModel>> GetPostingModels()
        {
           return await this.PostingDBModels.FromSql("GetPostings").ToListAsync();
        }

        public async Task<PostingDBModel> GetPostingById(int id)
        {
            PostingDBModel model = await this.PostingDBModels.FromSql($"GetPostingById {id}").FirstOrDefaultAsync();
            model.Description = File.ReadAllText($"{_env.WebRootPath}/uploads/posts/{ model.Description }");

            return model;
        }

        //Binded Object from View -> Create new model
        public async Task CreatePostingModel(PostingDBModel postingModel)
        {
            //markdown file name and path
            string fileName = postingModel.Title;

            await CreateMarkdownFileFromDescription("posts", $"{ fileName }.md", postingModel.Description);

            await Task.Run(() => this.Database.ExecuteSqlCommand("CreatePosting @p0, @p1, @p2, @p3",
                postingModel.Title,
                postingModel.Author,
                $"{ fileName }.md",
                postingModel.MinToRead));
        }

        public async Task UpdatePosting(PostingDBModel postingModel)
        {
            //markdown file name and path
            string fileName = postingModel.Title;

            await CreateMarkdownFileFromDescription("posts", $"{ fileName }.md", postingModel.Description);

            await Task.Run(() => this.Database.ExecuteSqlCommand("UpdatePosting @p0, @p1, @p2, @p3, @p4",
                postingModel.Id,
                postingModel.Title,
                postingModel.Author,
                $"{ fileName }.md",
                postingModel.MinToRead));
        }

        public async Task DeletePostingById(int id)
        {
            await Task.Run(() => this.Database.ExecuteSqlCommand("DeletePostingById @p0", id));
        }
        #endregion

        #region Private Methods
        private async Task CreateMarkdownFileFromDescription(string path, string fileNameWithExtension, string content)
        {
            if (content != null && content.Length > 0)
            {
                //Combine path with web root
                path = Path.Combine(_env.WebRootPath, "uploads", path).ToLower();

                //if path does not exist -> create it
                if (!Directory.Exists(path)) Directory.CreateDirectory(path);

                //Full path with file name
                string fullPath = Path.Combine(path, fileNameWithExtension);

                using (StreamWriter fileStream = new StreamWriter(fullPath))
                {
                    await fileStream.WriteAsync(content);
                }
            }
        }
        #endregion
    }
}
