﻿using BOKWeb.Models.DB;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BOKWeb.Models
{
    public class PostingRepository : IPostingRepository
    {
        private BOKWebContext _context;

        public PostingRepository(BOKWebContext context)
        {
            _context = context;
        }

        public PostingDBModel CreateEmptyPostingInstance()
        {
            return new PostingDBModel();
        }

        public async Task CreatePostingModel(PostingDBModel postingModel)
        {
            await _context.CreatePostingModel(postingModel);
        }

        public async Task<IEnumerable<PostingDBModel>> GetPostingModels()
        {
            return await _context.GetPostingModels();
        }

        public async Task<PostingDBModel> GetPostingById(int id)
        {
            return await _context.GetPostingById(id);
        }

        public async Task UpdatePosting(PostingDBModel postingModel)
        {
            await _context.UpdatePosting(postingModel);
        }

        public async Task DeletePostingById(int id)
        {
            await _context.DeletePostingById(id);
        }
    }
}
