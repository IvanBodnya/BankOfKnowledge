﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BOKWeb.Controllers;
using BOKWeb.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Westwind.AspNetCore.Markdown;

namespace BOKWeb
{
    public class Startup
    {
        private IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMarkdown();

            services.AddMvc();

            services.AddScoped<IPostingRepository, PostingRepository>();

            //Connection to SQL server
            services.AddDbContext<BOKWebContext>(options =>
            options.UseSqlServer(Configuration.GetConnectionString("BOKDatabase")));

            //Adds authentication to WSSO
            services.AddAuthentication(options =>
            {
                options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
            })
            .AddCookie()
            .AddOpenIdConnect(oidcOptions =>
            {
                /* These properties will change in every environment. Feel free to use my credentials for initial testing:
                * "SsoClientId": "8c68bd2d-0a10-4c4c-86bf-1f6c35213406",
                * "SsoClientSecret": "bafe7586-009e-4f49-9ed0-e29b407c6291",
                * "SsoClientUrl": "https://apps-bemsid-only.login.system.pcfpre-phx.cloud.boeing.com"
                * - These credentials only work on localhost ports 80, 3000, and 3001
                * - You should make your own in PCF, instructions in the Readme file
                */
                oidcOptions.Authority = Environment.GetEnvironmentVariable("SsoClientUrl");
                oidcOptions.ClientId = Environment.GetEnvironmentVariable("SsoClientId");
                oidcOptions.ClientSecret = Environment.GetEnvironmentVariable("SsoClientSecret");

                oidcOptions.GetClaimsFromUserInfoEndpoint = true;
                oidcOptions.ResponseType = OpenIdConnectResponseType.Code;
                oidcOptions.SaveTokens = true;
                oidcOptions.SignInScheme = "Cookies";

                // The SSO Service broker sets Boeing fields in odd fields, so it helps to map them
                oidcOptions.ClaimActions.MapAll();
                oidcOptions.ClaimActions.MapJsonKey("boeing:email", "email");
                oidcOptions.ClaimActions.MapJsonKey("boeing:bems", "user_name");
                oidcOptions.ClaimActions.MapJsonKey("boeing:name", "name");
            });
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseHttpsRedirection();
            app.UseMarkdown();
            
            app.UseStaticFiles();
            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Posting}/{action=Index}/{id?}");
            });

            app.Run(async (context) =>
            {
                await context.Response.WriteAsync("No MVC stuff found :-)");
            });
        }
    }
}
